library lib_c;

cStuff() => print('cStuff');