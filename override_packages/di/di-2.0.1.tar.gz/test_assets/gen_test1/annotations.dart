library annotations;

class InjectableTest {
  const InjectableTest();
}