library lib_common2;

import 'annotations.dart';

@InjectableTest()
class ServiceCommon2 {
  sayHi() {
    print('Hi ServiceCommon2!');
  }
}