library lib_common1;

import 'annotations.dart';

@InjectableTest()
class ServiceCommon1 {
  sayHi() {
    print('Hi ServiceCommon1!');
  }
}