#!/bin/bash
set -e
. ./scripts/env.sh

./run-benchmarks.sh