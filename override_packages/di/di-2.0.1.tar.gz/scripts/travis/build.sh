#!/bin/bash
set -e
. ./scripts/env.sh

./run-tests.sh