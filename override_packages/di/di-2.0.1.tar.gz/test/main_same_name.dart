library di.tests_same_name;

import 'package:di/di.dart';

@Injectable()
class Engine {}
