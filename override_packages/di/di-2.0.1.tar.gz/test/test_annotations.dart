library test_annotations;

class Broken {
  const Broken();
}

class Old {
  const Old();
}

class Turbo {
  const Turbo();
}
